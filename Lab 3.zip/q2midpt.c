//midpoint rule Q2
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main (void)
{
    FILE *fptr;

    fptr = fopen("a3q2mid1abserrorvsn.txt","w");

    if(fptr == NULL)
   {
      printf("Error");   
      exit(1);             
   }

    float x = 1.0;//upper limit
    float mid, fmid, abserror, mn = 0;

    for(int n = 4; n <= 1024; n = n * 2)//n is no of subintervals
    {

        float subl = (4.0 + x)/n;//length of each subinterval
        mn = 0;

        //i = subinterval number
        for(int i = 1; i <= n; i++)
        {
            mid = ((2*i - 1)*(x + 4))/(2*n) - 4;
            fmid = exp(-0.5 * mid * mid)/(pow(2 * M_PI, 0.5));
            mn = mn + subl * fmid;
        }
    
        float abserror = fabs((erf(x/pow(2,0.5)) + 1)/2.0 - mn);
        fprintf(fptr,"%d\t%f\n", n, abserror);
        printf("Approximate value of Erf(%f) = %f for %d subdivisions\nAbsolute error = %f\n", x, mn, n, abserror);
    }
    fclose(fptr);
    return(0);
}
  