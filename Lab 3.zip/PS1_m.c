#include <stdio.h>
#include <math.h>

int main()
{
    FILE *fp=fopen("midpoint.txt", "a");
    int n;
    scanf("%i", &n);
    float len=M_PI/n;//length of subinterval
    float integmid=0;
    for(int i=0; i<n; i++){
        float mid=len*(2*i+1)/2;//midpoint rule
        integmid+=len*sin(mid);
    }
    float errabsm=fabs(integmid-2.0);//absolute error
    fprintf(fp, "%i %f %f\n", n, integmid, errabsm);
    fclose(fp);
}
