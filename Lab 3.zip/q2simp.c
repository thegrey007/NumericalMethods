//simpson Q2

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

float func(float x);

int main (void)
{
    FILE *fptr;

    fptr = fopen("a3q2simp2abserrorvsn.txt","w");

    if(fptr == NULL)
   {
      printf("Error");   
      exit(1);             
   }

    float x = 2;//upper limit
    float fx0 = func(-4.0);
    float fxn = func(x);
    float fxi, xi, k;

    for(int n = 4; n <= 1024; n = n * 2)//n is no of subintervals
   {
       float subdivisionLength = (4.0 + x)/n;//length of each subinterval
       float sn = (subdivisionLength *(fx0 + fxn))/3.0;
    
        //i = subinterval number
        for(int i = 1; i < n; i++)
        {
            xi = i * subdivisionLength - 4;
            fxi = func(xi);
            k = (i%2==0?(2.0/3.0):(4.0/3.0));
            sn = sn + subdivisionLength * fxi * k;
        }

        float abserror = fabs((erf(x/pow(2,0.5)) + 1)/2.0 - sn);
        fprintf(fptr, "%d\t%f\n", n, abserror);
        printf("Approximate value of Erf(%f) = %f for %d subdivisions\nAbsolute error = %f\n", x, sn, n, abserror);
    }

    fclose(fptr);
    return(0);
}

float func(float x)
{
    float ans = exp(-0.5 * x * x)/(pow(2 * M_PI, 0.5)); 
    return(ans);
}