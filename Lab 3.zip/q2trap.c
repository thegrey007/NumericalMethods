#include <stdio.h>
#include <math.h>
#include <stdlib.h>

float func(float x);

int main (void)
{
    FILE *fptr;

    fptr = fopen("a3q2trap1abserrorvsn.txt","w");

    if(fptr == NULL)
   {
      printf("Error");   
      exit(1);             
   }


    float x = 1;//upper limit
    float fx0 = func(-4.0);
    float fxn = func(x);
    float fxi, xi;

    for(int n = 4; n <= 1024; n = n * 2)//n is no of subintervals
    {
        float subdivisionLength = (4.0 + x)/n;//length of each subinterval
        float tn = subdivisionLength *0.5 *(fx0 + fxn);
    
        //i = subinterval number
        for(int i = 1; i < n; i++)
        {
            xi = i * subdivisionLength - 4;
            fxi = func(xi);
            tn = tn + subdivisionLength * fxi;
        }
    
        float abserror = fabs((erf(x/pow(2,0.5)) + 1)/2.0 - tn);
        fprintf(fptr, "%d\t%f\n", n, abserror);
        printf("Approximate value of Erf(%f) = %f for %d subdivisions\nAbsolute error = %f\n", x, tn, n, abserror);
    }

    fclose(fptr);
    return(0);
}

float func(float x)
{
    float ans = exp(-0.5 * x * x)/(pow(2 * M_PI, 0.5)); 
    return(ans);
}