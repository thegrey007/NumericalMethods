#include <stdio.h>
#include <math.h>

int main()
{
    FILE *fp=fopen("trapezoidal.txt", "a");
    int n;
    scanf("%i", &n);
    float len=M_PI/n;//length of subinterval
    float integtrap=0;
    for(int i=0; i<n; i++){
        float midf=(sin(i*len)+sin((i+1)*len))/2;
        integtrap+=len*midf;//trapezoidal rule
    }
    float errabst=fabs(integtrap-2.0);//absolute error
    fprintf(fp, "%i %f %f\n", n, integtrap, errabst);
    fclose(fp);
}
