#include <stdio.h>
#include <math.h>

int main()
{
    FILE *fp=fopen("simpson.txt", "a");
    int n;
    scanf("%i", &n);
    float len=M_PI/n;//length of subinterval
    float integsimp=(sin(0)+sin(M_PI))*len/3;
    for(int i=0; i<n; i++){
        if(i%2!=0){//simpson's rule
            integsimp+=4*(sin(i*len))*len/3;
        }
        else{
            integsimp+=2*(sin(i*len))*len/3;
        }
    }
    float errabss=fabs(integsimp-2.0);//absolute error
    fprintf(fp, "%i %f %f\n", n, integsimp, errabss);
    fclose(fp);
}
