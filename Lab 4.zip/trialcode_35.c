#include <math.h>
#include <stdio.h>

#ifndef M_PI
#    define M_PI 3.14159265358979323846
#endif

int main() {
   int i, N = 100;
   float sum, true_sum;
   sum = 0.0;
   FILE *fp = NULL;

   /* the file to which the data is saved.
    It will be used later for plots. */
   fp = fopen("error_rates_fwd.txt","w");
   true_sum = pow(M_PI, 4) / 90.0;
   printf("true sum:%f\n", true_sum);

   // use "for (i = N; i >= 1; i--)" for the backward loop
   for (i = 1; i <= N; i++)
//   for (i = N; i >= 1; i--)
   {
   sum = sum + 1 / pow(i, 4);

   float err;

   // compute the error
   err = ((true_sum - sum) / true_sum) * 100;

   // debug on terminal
   printf("value of i:%d, sum: %f, err:%f\n", i, sum, err);
   fprintf(fp,"%d\t %f\n",i, err);
   }

   return 0;
}