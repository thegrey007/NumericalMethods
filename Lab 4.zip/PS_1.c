#include <stdio.h>
#include <time.h>

//Gauss elimination

int main()
{
    //initializing time at beginning of program for runtime calculation later
    clock_t t;
    t = clock();
    
    int n=3;
    float a[3][3];//3x3 array to store the values of coefficients
    
    a[0][0] = 7, a[0][1]= -31, a[0][2] = 3;
    a[1][0]=7, a[1][1]=4, a[1][2]=-16.6;
    a[2][0]=7, a[2][1]=-4, a[2][2]=-3;
    
    float b[3];//constant value array
    b[0]=-63, b[1]=-700, b[2]=-132;
    //Matrix manipulation
    for(int k=0; k<n-1; k++){
        for(int i=k+1; i<n; i++){
            float factor=a[i][k]/a[k][k];//pivot element
            for(int j=k+1; j<n; j++){
                a[i][j]=a[i][j]-(factor*a[k][j]);//updating the matrix after necessary operations
            } 
            b[i]-=factor*b[k];//updating constant value array
        }
    }
    //Back substitution
    float sum;
    float x[3];//variable array
    x[n-1] = b[n-1]/a[n-1][n-1];//value of xn
    for(int i = n - 2; i >= 0; i--)
    {
        sum = b[i];
        for (int j = i+1; j < n; j++)
        {
            sum = sum - a[i][j]*x[j];
        }
        x[i] = (sum)/a[i][i];//storing values of xi
    }
    //printing the values of xi
    for(int i = 0; i < 3; i++)
    {
        printf("V%i: ", i+1);
        printf("%f\n", x[i]);
    }
    //runtime calculation and display
    t = clock() - t;
    double time_taken = ((double)t)/CLOCKS_PER_SEC;
    printf("Time taken = %.15f\n", time_taken);
    return 0;
}