#include <stdio.h>
#include <math.h>
#include <time.h>

//Matrix inversion method using LU decomposition

int main()
{
     //initializing time at beginning of program for runtime calculation later
    clock_t t;
    t = clock();
    
    int n=3;
    float M[n][n];//Coefficient matrix declaration
    
    M[0][0] = 1, M[0][1]= 4, M[0][2] = -3;
    M[1][0]=-2, M[1][1]=8, M[1][2]=5;
    M[2][0]=3, M[2][1]=4, M[2][2]=7;
    
    float b[n];//Constant value array
    float L[n][n]; float U[n][n];//L and U matrices
    float Mi[n][n];//Inversion of matrix
    
    //Decomposition
    for(int k=0; k<n-1; k++){
        for(int i=k+1; i<n; i++){
            float factor=M[i][k]/M[k][k];//pivot element
            M[i][k]=factor;
            for(int j=k+1; j<n; j++){
                M[i][j]=M[i][j]-(factor*M[k][j]);//changing the original matrix to be a combination of L and U
            } 
        }
    }
    //Assigning L and U
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(i==j){
                L[i][j]=1;
                U[i][j]=M[i][j];
            }
            else if(i>j){
                L[i][j]=M[i][j];
                U[i][j]=0;
            }
            else{
                L[i][j]=0;
                U[i][j]=M[i][j];
            }
        }
    }
    //printing L and U
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            printf("%f ", L[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            printf("%f ", U[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    
    //Assigning values of b to get the inverse of the matrix
    for(int a=0; a<n; a++){
        if(a==0){
            b[0]=1, b[1]=0, b[2]=0;
        }
        else if(a==1){
            b[0]=0, b[1]=1, b[2]=0;
        }
        else{
            b[0]=0, b[1]=0, b[2]=1;
        }
        
        //Changing the values b to d array, here d satisfies Ld=b and Ux=d, using d allows us to use the same L and U matrices for multiple values of b (constant value matrix)
        float sum;
        for(int i = 1; i < n; i++)
        {
            sum = b[i];
            for( int j = 0; j <= i-1; j++)
            {
                sum = sum - M[i][j] * b[j];

            }
            b[i] = sum;
        }
        
        float x[n];//variable array for calculating M inverse
        x[n-1] = b[n-1]/M[n-1][n-1];
        for(int i = n - 2; i >= 0; i--)
        {
            sum = 0;
            for (int j = i+1; j < n; j++)
            {
                sum = sum + M[i][j]*x[j];

            }
            x[i] = (b[i] - sum)/M[i][i];

        }
        
        //M inverse
        for(int i = 0; i < n; i++)
        {
            Mi[i][a]=x[i];
        }
    }
    //printing M inverse
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            printf("%f ", Mi[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    
    
    //for decoeding the list numbers given, using the M inverse calculated above
    float e[n], d[n];//encoded and decoded string values
    int z=6;//value of z is 6 for part a, z is 12 for part b
    int s[z];//decoded string array
    for(int j=0; j<z/3; j++){
        for(int i=0; i<3; i++){
            scanf("%f", &e[i]);//input values from the question
        }
        //calculating decoded string array
        for(int i=0; i<n; i++){
            d[i]=0;
            for(int j=0; j<n; j++){
                d[i]+=Mi[i][j]*e[j];
            }
        }
        for(int i = 0; i < n; i++)
        {
            if((int)round(d[i])!=27){
                s[j*3+i]=(int)round(d[i]+64);
            }
            else{
                s[j*3+i]=32;
            }
        }
    }
    //printing the actual decoded string
    for(int i=0; i<z; i++){
        printf("%c", s[i]);
    }
    //runtime calculation and display
    t = clock() - t;
    double time_taken = ((double)t)/CLOCKS_PER_SEC;
    printf("Time taken = %.15f\n", time_taken);
    return 0;
}