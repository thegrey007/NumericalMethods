#include <stdio.h>
#include <math.h>

//This is the final output
/*Linear: a0 = 20.600000, a1 = 0.494545
r=0.915692
Power: 2.297856 0.385080
r=0.977375
Saturation: 0.019963 0.197464
r=0.996758
Parabola: 11.766684 1.377877 -0.016061
r=0.989941*/

//function to perform linear regression
void linear(float *arr, float *x, float *y){
    
    float a1=(10*arr[4]-arr[1]*arr[2])/(10*arr[3]-arr[1]*arr[1]);
    float a0=(arr[2]/10 - a1*(arr[1]/10));
    printf("Linear: %f %f\n", a0, a1);
    
    float sr=0, st=0;
    for(int i=0; i<10; i++){
        sr+=(y[i]-a0-a1*x[i])*(y[i]-a0-a1*x[i]);
        st+=(y[i]-arr[2]/10)*(y[i]-arr[2]/10);
    }
    
    //standard deviation
    float sy=sqrt(sr/(10-2));
    printf("Sy/x: %f\n", sy);

    //calculating coefficient of correlation
    float r=pow((st-sr)/st, 0.5);
    printf("r=%f\n", r);
}

//function to perform power equation regression
void power(float *arr, float *x, float*y){
    float cx[10], cy[10];
    float sumx=0, sumy=0, sumxy=0, sumx2=0;
    for(int i=0; i<10; i++){
        cx[i]=log(x[i]);
        cy[i] = log(y[i]);
        sumxy+= cx[i]*cy[i];
        sumx2+= cx[i]*cx[i];
        sumy+= cy[i];
        sumx+= cx[i];
    }
    
    float a1=(10*sumxy-sumx*sumy)/(10*sumx2-sumx*sumx);
    float a0=(sumy/10 - a1*(sumx/10));
    printf("Power: %f %f\n", a0, a1);
    
    float sr=0, st=0;
    for(int i=0; i<10; i++){
        sr+=(cy[i]-a0-a1*cx[i])*(cy[i]-a0-a1*cx[i]);
        st+=(cy[i]-sumy/10)*(cy[i]-sumy/10);
    }
    
    //standard deviation
    float sy=sqrt(sr/(10-2));
    printf("Sy/x: %f\n", sy);

    //calculating coefficient of correlation
    float r=pow((st-sr)/st, 0.5);
    printf("r=%f\n", r);
}

//function to perform saturation growth rate regression
void saturation(float *arr, float *x, float*y){
    
    float cx[10], cy[10];
    float sumx=0, sumy=0, sumxy=0, sumx2=0;
    for(int i=0; i<10; i++){
        cx[i]=1/x[i];
        cy[i]= 1/y[i];
        sumxy+= cx[i]*cy[i];
        sumx2+= cx[i]*cx[i];
        sumy+= cy[i];
        sumx+= cx[i];
    }
    float a1=(10*sumxy-sumx*sumy)/(10*sumx2-sumx*sumx);
    float a0=(sumy/10 - a1*(sumx/10));
    printf("Saturation: %f %f\n", a0, a1);
    float sr=0, st=0;
    for(int i=0; i<10; i++){
        sr+=(cy[i]-a0-a1*cx[i])*(cy[i]-a0-a1*cx[i]);
        st+=(cy[i]-sumy/10)*(cy[i]-sumy/10);
    }
    
    //standard deviation
    float sy=sqrt(sr/(10-2));
    printf("Sy/x: %f\n", sy);

    //calculating coefficient of correlation
    float r=pow((st-sr)/st, 0.5);
    printf("r=%f\n", r);
}

//function to perform polynomial regression
void parabola(float *arr, float *x, float *y){
    
    int q=3;
    float a[q][q];
    
    //initializing coefficient array
    a[0][0] = arr[0], a[0][1]=arr[1], a[0][2]=arr[3];
    a[1][0]=arr[1], a[1][1]=arr[3], a[1][2]=arr[5];
    a[2][0]=arr[3], a[2][1]=arr[5], a[2][2]=arr[6];

    //initializing constant value array
    float b[q];
    b[0]=arr[2], b[1]=arr[4], b[2]=arr[7];
    
    //Matrix manipulation using Gauss Elimination
    for(int k=0; k<q-1; k++){
        for(int i=k+1; i<q; i++){
            float factor=a[i][k]/a[k][k];
            for(int j=k+1; j<q; j++){
                a[i][j]=a[i][j]-(factor*a[k][j]);
            } 
            b[i]-=factor*b[k];
        }
    }
    
    
    float sum;
    float ans[q];
    ans[q-1] = b[q-1]/a[q-1][q-1];
    
    //back substitution 
    for(int i = q - 2; i >= 0; i--)
    {
        sum = b[i];
        for (int j = i+1; j < q; j++)
        {
            sum = sum - a[i][j]*ans[j];

        }
        ans[i] = (sum)/a[i][i];
    }
    
    
    printf("Parabola: %f %f %f\n", ans[0], ans[1], ans[2]);
    float sr=0, st=0;
    for(int i=0; i<arr[0]; i++){
        sr+=(y[i]-ans[0]-ans[1]*x[i]-ans[2]*x[i]*x[i])
        *(y[i]-ans[0]-ans[1]*x[i]-ans[2]*x[i]*x[i]);
        st+=(y[i]-arr[2]/arr[0])*(y[i]-arr[2]/arr[0]);
    }

    //standard deviation
    float sy=sqrt(sr/(10-2));
    printf("Sy/x: %f\n", sy);
    
    //calculating coefficient of correlation
    float r=pow((st-sr)/st, 0.5);
    printf("r=%f\n", r);
}

int main()
{
    FILE *fp=fopen("data2.txt", "r");
    
    //n stores no of datapoints
    int n=10;
    
    //arrays for storing x and y coordinates of datapoints 
    float x[n], y[n];
    float sumx=0, sumy=0, sumxy=0, sumx2=0, sumx3=0, sumx4=0, sumx2y= 0;
    for(int i=0; i<n; i++){
        fscanf(fp, "%f %f", &x[i], &y[i]);
        sumxy+= x[i]*y[i];
        sumx2+= x[i]*x[i];
        sumy+= y[i];
        sumx+= x[i];
        sumx3+=x[i]*x[i]*x[i];
        sumx4+= x[i]*x[i]*x[i]*x[i];
        sumx2y+= x[i]*x[i]*y[i];
    }
    
    float coeff[]={(float)n, sumx, sumy, sumx2, sumxy, sumx3, sumx4, sumx2y};

    //calling functions for various regressions
    linear(&coeff[0], &x[0], &y[0]);
    power(&coeff[0], &x[0], &y[0]);
    saturation(&coeff[0], &x[0], &y[0]);
    parabola(&coeff[0], &x[0], &y[0]);
    
    //closing file data2.txt
    fclose(fp);
}