#include <stdio.h>
#include <math.h>

int main()
{
    FILE *fp=fopen("data1.txt", "r");
    
    //Linear regression
    int n=11;
    int x[n], y[n];
    int sumx=0, sumy=0, sumxy=0, sumx2=0;
    for(int i=0; i<n; i++){
        fscanf(fp, "%i %i", &x[i], &y[i]);
        sumxy+= x[i]*y[i];
        sumx2+= x[i]*x[i];
        sumy+= y[i];
        sumx+= x[i];
    }
    //calculating a0 and a1
    float a1=(float)(n*sumxy-sumx*sumy)/(n*sumx2-sumx*sumx);
    float a0=(float)(sumy/n - a1*(sumx/n));
    printf("a0=%f a1=%f\n", a0, a1);
    //calculating standard error
    float sr, st;
    for(int i=0; i<n; i++){
        sr+=(float)(y[i]-a0-a1*x[i])*(y[i]-a0-a1*x[i]);
        st+=(float)(y[i]-sumy/n)*(y[i]-sumy/n);
    }
    printf("Sr=%f St=%f\n", sr, st);
    //calculating correlation coefficient
    float r=pow((st-sr)/st, 0.5);
    printf("r=%f\n", r);
    
    //standard deviation
    float sy=sqrt(sr/(n-2));
    printf("Sy/x: %f\n", sy);
    
    //Predictions for x=10 and y=10
    printf("Value of y for x=10: %f\n", a0+a1*10);
    printf("Standard square error of (10,10): %f\n", (10-a0-a1*10)*(10-a0-a1*10));
    fclose(fp);
}