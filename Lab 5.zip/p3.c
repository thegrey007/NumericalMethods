#include <stdio.h>
#include <math.h>

//calculating parabola regression and estimating the value of µ for T=7.5◦C
void parabola(double *arr, double *x, double *y){
    
    int q=3;
    double a[q][q];
    
    a[0][0] = arr[0], a[0][1]=arr[1], a[0][2]=arr[3];
    a[1][0]=arr[1], a[1][1]=arr[3], a[1][2]=arr[5];
    a[2][0]=arr[3], a[2][1]=arr[5], a[2][2]=arr[6];

    double b[q];
    b[0]=arr[2], b[1]=arr[4], b[2]=arr[7];
    for(int k=0; k<q-1; k++){
        for(int i=k+1; i<q; i++){
            float factor=a[i][k]/a[k][k];
            for(int j=k+1; j<q; j++){
                a[i][j]=a[i][j]-(factor*a[k][j]);
            } 
            b[i]-=factor*b[k];
        }
    }
    double sum;
    double ans[q];
    ans[q-1] = b[q-1]/a[q-1][q-1];
    for(int i = q - 2; i >= 0; i--)
    {
        sum = b[i];
        for (int j = i+1; j < q; j++)
        {
            sum = sum - a[i][j]*ans[j];

        }
        ans[i] = (sum)/a[i][i];
    }
    printf("Expected value for T=7.5 using quadratic regression: %.9f", ans[0]+ans[1]*7.5+ans[2]*7.5*7.5);
}


int main()
{
    FILE *fp=fopen("data3.txt", "r");
    
    //n stores the no of data points
    int n=6;
    
    //arrays to store x and y coordinates of each data point
    double x[n], y[n];
    double arr[n][n];
    for(int i=0; i<n; i++){
        fscanf(fp, "%lf %lf", &x[i], &y[i]);
        arr[i][0]=y[i];
    }
    //Newton divided difference interpolation 
    //calculating columns of divided differences using the previous columns
    for(int i=1; i<n; i++)
    {
        for(int j=0;j<n;j++)
        {
            if(j>(5-i)){
            arr[j][i]=0;}
            else
            {
                arr[j][i]=(arr[j+1][i-1]-arr[j][i-1])/(x[i+j]-x[j]);
            }
        }
    }
    
    //printing the matrix of divided differences
    for (int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            printf("%.9f\t", arr[i][j]);
        }
        printf("\n");
    }
     double ans=0;
     
    //calculating value of µ from Newton Divided Difference interpolation
    
    for(int i=0; i<6; i++){
        double k=1;
        for(int j=0;j<i;j++)
        {
        k*=(7.5-x[j]);
        }
        ans+=arr[0][i]*k;
    }
    printf("Expected value for T=7.5: %.9f\n", ans);
    
    //polynomial regression
    double sumx=0, sumy=0, sumxy=0, sumx2=0, sumx3=0, sumx4=0, sumx2y= 0;
    for(int i=0; i<n; i++){
        sumxy+= x[i]*y[i];
        sumx2+= x[i]*x[i];
        sumy+= y[i];
        sumx+= x[i];
        sumx3+=x[i]*x[i]*x[i];
        sumx4+= x[i]*x[i]*x[i]*x[i];
        sumx2y+= x[i]*x[i]*y[i];
    }
    
    double coeff[]={(double)n, sumx, sumy, sumx2, sumxy, sumx3, sumx4, sumx2y};
    
    //calling function parabola()
    parabola(&coeff[0], &x[0], &y[0]);
}