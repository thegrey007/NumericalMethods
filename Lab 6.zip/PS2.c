#include <stdio.h>
#include <math.h>

double diff(double t, double y){//differential equation function
    return -100000*y+99999*exp(-t);
}

void eeuler(double t, double yi){//explicit euler methid
    double h=0.00001;//step size chosen
    double size = 2/h;//number of subdivisions for the chosen h
    FILE *fp=fopen("ee.txt", "w");//files with points using explicit euler method
    fprintf(fp, "%f %f\n", t, yi);
    double y;
    for(int i=0; i<size; i++){
        y=yi+diff(t, yi)*h;//update equation
        fprintf(fp, "%f %f\n", t+h, y);
        t+=h;
        yi=y;
    }
    fclose(fp);
}

void ieuler(double t, double yi){//implicit euler method
    double h=0.1;//step size
    double size = 2/h;//number of subdivisions for the chosen h
    FILE *fp=fopen("ie.txt", "w");//files with points using implicit euler method
    fprintf(fp, "%f %f\n", t, yi);
    double y;
    for(int i=0; i<size; i++){
        y=(yi+99999*h*exp(-(t+h)))/(100000*h+1);//update equation worked out by hand
        fprintf(fp, "%f %f\n", t+h, y);
        t+=h;
        yi=y;
    }
    fclose(fp);
}

int main()
{
    eeuler(0, 0);//explicit euler function
    ieuler(0, 0);//implicit euler function
}