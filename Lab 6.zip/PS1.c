#include <stdio.h>
#include <time.h>
#include <math.h>

//declaring value of h (can be changed to different values to get results accordingly)
const double h=0.1;
double size = 2/h;//number of subdivisions based on h

double diff(double t, double y){//differential equation function
    return y*pow(t, 3) - 1.5*y;
}

double func(double t)//true equation function
{
    return exp((pow(t,4)/4.0)-1.5 *t);
}

void euler(double t, double yi){//Euler method
    FILE *fp=fopen("ye.txt", "w");//file containing points by euler method
    FILE *fq=fopen("erre.txt", "a");//file with the absolute error vs h by euler method
    fprintf(fp, "%f %f\n", t, yi);
    double y;
    for(int i=0; i<size; i++){
        y=yi+diff(t, yi)*h;//update equation
        fprintf(fp, "%f %f\n", t+h, y);
        t+=h;
        yi=y;
    }
    double erra=fabs(y-func(2));//absolute error
    fclose(fp);
    fprintf(fq, "%f %f\n", h, erra);
    fclose(fq);
}

void heun(double xi, double yi)//Heun's method
{
    FILE *fp=fopen("he.txt", "w");//file containing points by Heun's method
    FILE *fq=fopen("errh.txt", "a");//file with the absolute error vs h by Heun's method
    fprintf(fp, "%f %f\n", xi, yi);
    double yi10;
    for(int i = 1; i <=size; i++, xi+=h)
    {
        yi10 = yi + h*diff(xi, yi);//intermediate equation
        yi= yi + h*0.5 * (diff(xi,yi)+diff((xi+h), yi10));//update equation
        fprintf(fp, "%f %f\n", xi+h, yi);
    }
    double erra=fabs(yi-func(2));//absolute error
    fclose(fp);
    fprintf(fq, "%f %f\n", h, erra);
    fclose(fq);
}

void midpoint(double t, double yi){//Midpoint method
    FILE *fp=fopen("me.txt", "w");//file containing points by Midpoint method
    FILE *fq=fopen("errm.txt", "a");//file with the absolute error vs h by Midpoint method
    fprintf(fp, "%f %f\n", t, yi);
    double y;
    for(int i=0; i<size; i++){
        double yf=yi+diff(t, yi)*(h/2);//intermediate equation
        y=yi+diff(t+h/2, yf)*h;//update equation
        fprintf(fp, "%f %f\n", t+h, y);
        t+=h;
        yi=y;
    }
    double erra=fabs(y-func(2));//absolute error
    fclose(fp);
    fprintf(fq, "%f %f\n", h, erra);
    fclose(fq);
}

void rk(double t, double yi){//Runge-Kutta method
    FILE *fp=fopen("re.txt", "w");//file containing points by Runge-Kutta method
    FILE *fq=fopen("errr.txt", "a");//file with the absolute error vs h by Runge-Kutta method
    fprintf(fp, "%f %f\n", t, yi);
    double y;
    double k1, k2, k3, k4;//intermediate coefficients to approximate the function to fourth order
    for(int i=0; i<size; i++){
        k1=diff(t, yi);
        k2=diff(t+h/2, yi+(k1*(h/2)));
        k3=diff(t+h/2, yi+(k2*(h/2)));
        k4=diff(t+h, yi+(k3*h));
        y=yi+(1/6.0)*(k1+(2*k2)+(2*k3)+(k4))*h;//update equation
        fprintf(fp, "%f %f\n", t+h, y);
        t+=h;
        yi=y;
    }
    double erra=fabs(y-func(2));//absolute error
    fclose(fp);
    fprintf(fq, "%f %f\n", h, erra);
    fclose(fq);
}

int main()
{
    //for calculating runtime
    clock_t t1;
    t1 = clock();
    euler(0, 1);//calling euler function
    //runtime calculation and display
    t1 = clock() - t1;
    double time_taken = ((double)t1)/CLOCKS_PER_SEC;
    printf("Time taken = %.15f\n", time_taken);
    t1 = clock();
    heun(0, 1);//calling heun function
    //runtime calculation and display
    t1 = clock() - t1;
    time_taken = ((double)t1)/CLOCKS_PER_SEC;
    printf("Time taken = %.15f\n", time_taken);
    t1 = clock();
    midpoint(0, 1);//calling midpoint function
    //runtime calculation and display
    t1 = clock() - t1;
    time_taken = ((double)t1)/CLOCKS_PER_SEC;
    printf("Time taken = %.15f\n", time_taken);
    t1 = clock();
    rk(0, 1);//calling rk function
    //runtime calculation and display
    t1 = clock() - t1;
    time_taken = ((double)t1)/CLOCKS_PER_SEC;
    printf("Time taken = %.15f\n", time_taken);
}